Интернет-магазин по заказу пиццы - **React Pizza**

- [Плейлист с полным курсом на YouTube](https://www.youtube.com/watch?v=bziVFvq8cLQ&list=PL0FGkDGJQjJFMRmP7wZ771m1Nx-m2_qXq)
- [Как задеплоить React Pizza на бесплатный хостинг](https://www.youtube.com/watch?v=-pJN9faoa8E&t=1951s)

**Stack:**

- ReactJS + хуки
- React Router
- Redux
- Redux thunk
- json-server
- Axios
- classnames
